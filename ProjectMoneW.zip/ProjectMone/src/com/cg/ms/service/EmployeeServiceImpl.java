package com.cg.ms.service;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.ms.dao.EmployeeDAO;
import com.cg.ms.dao.EmployeeDAOImpl;
import com.cg.ms.dto.Employee;
import com.cg.ms.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDAO dao;
	public EmployeeServiceImpl()
	{
		dao=new EmployeeDAOImpl();
	}
	
	
	@Override
	public int addDetail(Employee employee) throws EmployeeException{
		// TODO Auto-generated method stub
		return dao.addDetail(employee);
	}


	@Override
	public Employee getEmployee(int id) {
		
		return dao.getEmployee(id);
	}


	@Override
	public Employee updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(employee);
	}


	@Override
	public ArrayList<Employee> getEmployeeList(String projname) {
		// TODO Auto-generated method stub
		return dao.getEmployeeList(projname);
	}

	@Override
	public Employee validateDetails(Employee emp) {
		
		if( (validateName(emp.getEname())) && (validateProjname(emp.getProjectname())) && (validateSalary(emp.getSalary())) && validatePhoneNo(emp.getMobNo()) && validateEmail(emp.getEmailId()))
			return emp;
		else 
			return null;
		
	}


	@Override
	public boolean validateName(String name) {
		Pattern pat=Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat=pat.matcher(name);
		return mat.matches();
	}


	@Override
	public boolean validateSalary(Double salary) {
		String sal=salary.toString();
		return (sal.matches("\\d{4,9}\\.\\d{0,4}"));
	}


	@Override
	public boolean validateProjname(String projname) {
		Pattern pat=Pattern.compile("[A-Z][a-z]{3,12}");
		Matcher mat=pat.matcher(projname);
		return mat.matches();
	}

	@Override
	public boolean validatePhoneNo(String mob) {
		Pattern pat=Pattern.compile("[0-9]{10}");
		Matcher mat=pat.matcher(mob);
		return mat.matches();
	}

	@Override
	public boolean validateEmail(String email) {
		Pattern pat=Pattern.compile("[A-Za-z0-9]{2,15}@capgemini.com");
		Matcher mat=pat.matcher(email);
		return mat.matches();
	}
	
	
	
	
}
