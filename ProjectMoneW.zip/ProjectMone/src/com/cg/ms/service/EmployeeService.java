package com.cg.ms.service;

import java.util.ArrayList;

import com.cg.ms.dto.Employee;
import com.cg.ms.exception.EmployeeException;


public interface EmployeeService {

	public int addDetail(Employee employee) throws EmployeeException;

	public Employee getEmployee(int id);
	public Employee updateEmployee(Employee employee);
	public ArrayList<Employee> getEmployeeList(String cname);
	
	public Employee validateDetails(Employee emp);
	public boolean validateName(String name);
	public boolean validateSalary(Double salary);
	public boolean validateProjname(String projname);

	public boolean validatePhoneNo(String mob);
    public boolean validateEmail(String email);
	
	
}