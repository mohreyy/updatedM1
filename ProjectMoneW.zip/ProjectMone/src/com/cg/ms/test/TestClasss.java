package com.cg.ms.test;

import static org.junit.Assert.*;
import junit.framework.Assert;

import org.junit.Test;

import com.cg.ms.exception.EmployeeException;
import com.cg.ms.service.EmployeeService;
import com.cg.ms.service.EmployeeServiceImpl;



public class TestClasss {
	@Test(expected=	NullPointerException.class)
	public void test_ValidateName_null(){
		EmployeeService p=new EmployeeServiceImpl();
		p.validateName(null);
	}
	
	@Test
	public void test_validateName_v1() {
		String name="Aete121";
		EmployeeService p=new EmployeeServiceImpl();
		boolean result=p.validateName(name);
		Assert.assertEquals(false, result);
		
	}
	
	@Test
	public void test_validateName_v2(){
		String name="Amita";
		EmployeeService p=new EmployeeServiceImpl();
		boolean result=p.validateName(name);
		Assert.assertEquals(true, result);
	}
	

	@Test
	public void test_validateName_v3(){
		String name="amita";
		EmployeeService p=new EmployeeServiceImpl();
		boolean result=p.validateName(name);
		Assert.assertEquals(false, result);
	}
	
	@Test
	public void test_validateSalary_v4(){
		double salary=50000;
		EmployeeService p=new EmployeeServiceImpl();
		boolean result=p.validateSalary(salary);
		Assert.assertEquals(true, result);
	}
	
	@Test
	public void test_validateName_v5(){
		String empname="Amita";
		EmployeeService p=new EmployeeServiceImpl();
		boolean result=p.validateName(empname);
		Assert.assertEquals(true, result);
	}
	
	
}
