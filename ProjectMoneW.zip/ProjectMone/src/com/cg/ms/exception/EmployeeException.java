package com.cg.ms.exception;

public class EmployeeException extends Exception{
	public EmployeeException(String message){
		super();
		}

}
