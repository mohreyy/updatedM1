package com.cg.ms.dao;

import java.util.ArrayList;

import com.cg.ms.dto.Employee;
import com.cg.ms.exception.EmployeeException;

public interface EmployeeDAO {

	int addDetail(Employee employee) throws EmployeeException;

	Employee getEmployee(int id);

	Employee updateEmployee(Employee employee);

	ArrayList<Employee> getEmployeeList(String projname);
	

}