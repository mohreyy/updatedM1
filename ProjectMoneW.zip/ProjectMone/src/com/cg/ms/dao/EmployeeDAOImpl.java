package com.cg.ms.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import com.cg.ms.dto.Employee;
import com.cg.ms.exception.EmployeeException;

public class EmployeeDAOImpl<empMap> implements EmployeeDAO {

	Map<Integer,Employee> empMap;
	public EmployeeDAOImpl()
	{
		empMap=DataStore.createCollection();
	}
	
	
	@Override
	public int addDetail(Employee employee) throws EmployeeException {
		int id=(int)(1000*Math.random());
		employee.setEmpId(id);
		empMap.put(id,employee);
		return id;
	}



	@Override
	public Employee getEmployee(int id) {
		Employee e=empMap.get(id);
		return e;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		empMap.put(employee.getEmpId(), employee);
		return employee;
	}


	@Override
	public ArrayList<Employee> getEmployeeList(String projname) {
		
		Collection<Employee> eList=empMap.values(); 
		ArrayList<Employee> employees=new ArrayList<>();
		

		for(Employee e:eList)
		{
		if(e.getProjectname().equals(projname)){
			employees.add(e);
		}
		}
		
		return employees;
	}
	

}