package com.cg.ms.ui;

import java.util.ArrayList;
import java.util.Scanner;


import com.cg.ms.dto.Employee;
import com.cg.ms.exception.EmployeeException;
import com.cg.ms.service.EmployeeService;
import com.cg.ms.service.EmployeeServiceImpl;



public class Main {

	public static void main(String args[]) throws EmployeeException {
		EmployeeService service=new EmployeeServiceImpl();
		//Employee emp=new Employee();
		Scanner sc=new Scanner(System.in);
		Scanner sc1=new Scanner(System.in);
		int ch=0;
		do{
			
			System.out.println("**************************");
			System.out.println("1. Add EMPLOYEE Details:  ");
			System.out.println("2. Display EMPLOYEE Details:  ");
			System.out.println("3. Update EMPLOYEE Details:  ");
			System.out.println("4. Display EMPLOYEE List:  ");
			System.out.println("5. Exit:  \n");
			System.out.println("Enter your choice ");
			ch = sc.nextInt();
			
			switch (ch) {
			case 1:
				Employee employee = null;
				do{
				System.out.println("Enter EMPLOYEE Name:");
				String name = sc1.nextLine();
				
				System.out.println("Enter Salary:");
				double salary = sc1.nextDouble();

                System.out.println("Enter project Name:");
				String cname = sc.next();

				System.out.println("Enter Age:");
				int age = sc.nextInt();

				System.out.println("Enter Contact No.:");
				String mob = sc.next();
				
				System.out.println("Enter Email Id");
				String email=sc.next();
				
				employee = new Employee();
				employee.setEname(name);
				employee.setProjectname(cname);
				employee.setAge(age);
				employee.setSalary(salary);
				employee.setMobNo(mob);
				employee.setEmailId(email);
				
				try{
				if(service.validateDetails(employee)!=null)
					break;
				else
						System.out.println("invalid details entered");
				}catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
				}while(true);
	
				int id = service.addDetail(employee);
				System.out.println("emp record added " + id);
				System.out.println(employee.toString());
				
				break;

				
		case 2:
			System.out.println("Enter Employee id no: ");
			id = sc.nextInt();
			
				employee = service.getEmployee(id);
				if (employee == null)
					System.err.println("Record not found...\n");
				else {
					
					System.out.println(employee.toString());
				}
			break;
			
			
			
		
		case 3:

			System.out.println("Enter empid: ");
			int empid=sc.nextInt();
			employee=service.getEmployee(empid);
			if (employee == null)
				System.err.println("Record not found...\n");
			else {
				System.out.println("Enter new Mobile No: ");
				String mobno=sc.next();
				employee.setMobNo(mobno);
				employee=service.updateEmployee(employee);
				System.out.println("Record Updated");
				System.out.println(employee.toString());
			}
			break;
		
			
			
		case 4:
		
			System.out.println("Enter project Name: ");
			String projname=sc.next();
		
//			if(service.validateProjname(projname)!=null)
//				break;
//			else
//				System.out.println(" project entered is incorrect");
		
			
			
			ArrayList<Employee> list=service.getEmployeeList(projname);
			if(list.size()==0)
			{
				System.err.println("No emp enrolled to this record...");
			}
				else
				{
				for(Employee e: list){
					System.out.println(e.getAge()+ " "+e.getMobNo());
					System.out.println();
				}}
			
			break;
		
	}
	}while(ch!=5);
	}}